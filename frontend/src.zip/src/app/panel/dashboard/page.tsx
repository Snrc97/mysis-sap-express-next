
'use client'
import "@/styles/globals.css";
import PageContainer from "@/components/layout/page-container";


const Dashboard: React.FC = () => {




  return (

    <PageContainer>

    </PageContainer>




  );
};

export default Dashboard;
